<?php
/**
 * @package    Procab_Reseller
 * @author     prasannanwr@gmail.com
 */
class Procab_Reseller_Helper_Data extends Mage_Core_Helper_Abstract
{
}